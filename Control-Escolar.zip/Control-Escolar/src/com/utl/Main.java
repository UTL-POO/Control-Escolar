package com.utl;

import com.utl.ventanas.Ingreso;
import com.utl.ventanas.admin.AlumnosVentana;

public class Main {

    public static void main(String[] args) {
        Ingreso ingreso = new Ingreso();
        AlumnosVentana alumnos = new AlumnosVentana();
    }
}
