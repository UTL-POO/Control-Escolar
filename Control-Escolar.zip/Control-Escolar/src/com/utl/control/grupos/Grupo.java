package com.utl.control.grupos;

public class Grupo {
    
    public String clave;
    public Alumno[] alumnos;

    public String consultarClave() { return clave; }
    public Alumno[] consultarAlumnos() { return alumnos; }

}
