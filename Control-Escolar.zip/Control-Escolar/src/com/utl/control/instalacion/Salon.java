package com.utl.control.instalacion;

public class Salon {

    private int c_salon;
    private int edificio;

    public int consultarCSalon() { return this.c_salon; }
    public int consultarEdificio() { return this.edificio; }
    
}
