package com.utl.control;

public class Escuela {

    private String nombre;
    private String ubicacion;
    private int telefono;

    public String consultarNombre() { return this.nombre; }
    public String consultarUbicacion() { return this.ubicacion; }
    public int consultarTelefono() { return this.telefono; }

}
